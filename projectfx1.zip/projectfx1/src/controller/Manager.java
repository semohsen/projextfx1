package controller;

import modle.BusinessAccount;
import modle.NormalAccount;

import java.util.ArrayList;
import java.util.*;


public class Manager {
    ArrayList<String> a = new ArrayList<>();

    private Scanner scanner = new Scanner(System.in);
    private ArrayList<BusinessAccount> businessAccounts;
    private ArrayList<NormalAccount> normalAccounts;

    public Manager() {
        this.businessAccounts = new ArrayList<>();
        this.normalAccounts = new ArrayList<>();
    }


    private NormalAccount normalAccount;
    private BusinessAccount businessAccount;

    public Manager(NormalAccount normalAccount, BusinessAccount businessAccount) {
        this.businessAccount = businessAccount;
        this.normalAccount = normalAccount;
    }

    public NormalAccount getNormalAccountByNormalAccountName(String name) {
        for (NormalAccount normalAccount : normalAccounts) {
            if (normalAccount.getName().equals(name)) {
                return normalAccount;
            }
        }
        return null;
    }

    public BusinessAccount getBusinessAccountByBusinessAccountName(String BusinessAccountName) {
        for (BusinessAccount businessAccount : businessAccounts) {
            if (businessAccount.getName().equals(BusinessAccountName)) {
                return businessAccount;
            }
        }
        return null;
    }
    }

