package view;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;

import controller.*;
import modle.*;

public class InputProcessor {
    private Scanner scanner = new Scanner(System.in);
    private Manager manager;
    ArrayList<String> a = new ArrayList<>();

    public InputProcessor(Manager manager) {
        this.manager = manager;
    }

    private void processCreateAccounts(String username) throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        String input="";
        while (!input.startsWith("asjfdkhhdjfsa")) {
            System.out.println("chose account type");
            System.out.println("1: normal Account");
            System.out.println("2: business Account");
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("1")) {
                NormalAccount.processCreateNormalAccounts(username);
                return;
            } else if (input.equalsIgnoreCase("2")) {
                BusinessAccount.processCreateBusinessAccounts(username);
                return;
            }
        }
    }

    public void run() throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        String input = "";
        System.out.println("THE APP is Running ...");
        while (input != "exit") {
            System.out.println(" \nEnter one of  Signup - login - forgetPassword - exit \n ");
            input = scanner.nextLine();
            input = input.toLowerCase();

            if (input.startsWith("login")) {
                System.out.println("Please Enter Your Username ... ");
                String username = scanner.nextLine();
                System.out.println("Please Enter Your Password ... ");
                String password = scanner.nextLine();
                String rr = username + "-" + password;
                Login.loginuser(rr);
            }

            if (input.startsWith("signup")) {
                System.out.println("Please Enter Username ... ");
                String username = "";
                username = scanner.nextLine();
                boolean userbool = false;
                while (!userbool) {
                    userbool = Signup.findUser(username);
                    if (userbool == false)
                        username = scanner.nextLine();
                }
                String password = UserInfo.makepassword();
                Signup.makeUser(username, password);

                processCreateAccounts(username);
            }
            if (input.startsWith("forgetPassword")) {
                System.out.println("What is your username ?");
                String username = scanner.nextLine();
                ForgetPassword.resetPassword(username);
            }
            input = "";
        }


        while (!(input = scanner.nextLine()).equalsIgnoreCase("exit")) {
            if (input.equalsIgnoreCase("create account")) {
                //   processCreateAccounts();
            }
        }
    }

    public static void loginRun(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Enter one of:\n block user-show blocked-unblock\n-follow-unfollow\n-private chat-\n" +
                    "create group-tweet-mygroup\n-ShowTweet-TimeLine-Recommend-AD-exit \n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("follow")) {
                System.out.println("Enter the username you want to follow :");
                String following = scanner.nextLine();
                Follow.follow(username, following);
            }
            if (input.startsWith("unfollow")) {
                System.out.println("Enter the username you want to unfollow :");
                String following = scanner.nextLine();
                Follow.unfollow(username, following);
            }

            if (input.startsWith("exit"))
                return;

            if (input.startsWith("tweet")) {
                tweetRun(username);
            }

            if (input.startsWith("showtweet")) {
                tweet.Showtweet(username);
            }

            if (input.startsWith("timeline")) {
                TimeLine.ShowTimeLine(username);
                TimeLineRun(username);
            }

            if (input.startsWith("recommend")) {
                RecommendRun(username);
            }

            if (input.startsWith("block user")) {
                blockUser(username);
            }

            if (input.startsWith("show blocked")) {
                Block.showBlockedUser(username);
            }

            if (input.startsWith("unblock")) {
                unblock(username);
            }

            if (input.startsWith("private chat")) {
                privateChat(username);
            }
            if (input.startsWith("create group")) {
                createGroup(username);
            }
            if (input.startsWith("mygroup")) {
                mygroup(username);
            }
            if(input.startsWith("ad"))
            {
                ad.sendAd(username);
            }
        }
    }

    public static void tweetRun(String username) {
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Enter one of SendTweet-DeleteTweet-exit\n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("exit"))
                return;
            if (input.startsWith("sendtweet")) {
                tweet.sendTweet(username);
            }
            if (input.startsWith("deletetweet")) {
                System.out.println("what is the number of tweet ? ");
                int number = scanner.nextInt();
                tweet.deletTweet(username, number);
            }
        }
    }

    public static void TimeLineRun(String username) {
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Enter one of AddComment-DeleteComment-Like-ShowComments-exit\n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("exit"))
                return;
            if (input.startsWith("addcomment")) {
                System.out.println("What is the number of tweet in your TimeLine ? ");
                int number = scanner.nextInt();
                comment.addComment(username, number);
            }
            if (input.startsWith("like")) {
                System.out.println("what is the number of tweet in your timeLine ? ");
                int number = scanner.nextInt();
                Likerun(username, number);
            }
            if (input.startsWith("deletecomment")) {
                System.out.println("What is the number of tweet in your TimeLine ? ");
                int number = scanner.nextInt();
                String owner = comment.findOwner(username, number);
                comment.deleteComment(username, owner, number);
            }
            if (input.startsWith("showcomments")) {
                System.out.println("What is the number of tweet in your TimeLine ? ");
                int number = scanner.nextInt();
                comment.findTweet(username, number);
                String tweet = comment.answer;
                tweet = tweet.trim();
                String owner = tweet.substring(tweet.indexOf('-') + 1, tweet.indexOf(' '));
                comment.ShowComment(username, number, owner);
            }

        }
    }

    public static void Likerun(String username, int tweet_number) {
        String table_name = comment.FindTableName(username, tweet_number);
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Enter one of Like-DisLike-amountOfLike-ShowLike-exit\n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("exit"))
                return;
            if (input.startsWith("like")) {
                Like.like(username, tweet_number, table_name);
            }
            if (input.startsWith("dislike")) {
                Like.Dislike(username, tweet_number, table_name);
            }
            if (input.startsWith("amountoflike")) {
                Like.AmountOfLike(username, tweet_number, table_name);
            }
            if (input.startsWith("showlike")) {
                Like.Showlike(username, tweet_number, table_name);
            }
        }
    }

    public static void RecommendRun(String username) {
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Recommend user or tweet (exit )? \n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("exit"))
                return;
            if (input.startsWith("tweet")) {
                Recommend.Recommend_tweet(username);
            }
            if (input.startsWith("user")) {
                Recommend.Recommend_user(username);
            }
        }
    }

    public static void privateChat(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);
        Scanner scanner = new Scanner(System.in);
        String input = "";
        System.out.println("Enter the username you want to chat with (him,her) :");
        String username2 = scanner.nextLine();
        while (!tableExist(conn,username2)){
            System.out.println(" username dosent exist enter username with is exist:");
            username2 = scanner.nextLine();
        }

        if (Block.checkBlock(username2,username)){
                System.out.println("you blocked can't send message");
                return;
            }

        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        nameChat=nameChat.toLowerCase(Locale.ROOT);


        String privateChatText = "";
        if(!tableExist(conn,nameChat)){
            System.out.println("Enter the text you want to send user :");
            privateChatText = scanner.nextLine();
          // start chat
            PrivateChat.startPrivateChat(username, username2, privateChatText);
            //continue chat

            System.out.println("if you want finish chat write exit");
            System.out.println("Enter the text you want to send user :");
            PrivateChat.ShowChat(username,username2);
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {
                 PrivateChat.privateChat( username, username2, privateChatText);
                privateChatText = scanner.nextLine();
            }
        }
        else {//continue chat


            PrivateChat.ShowChat(username,username2);
            System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {

                String Text="";
                    if (Objects.equals(privateChatText, "send message")) {
                        System.out.println("Enter the text you want to send user : -exit");
                        Text=scanner.nextLine();
                        while (!Objects.equals(Text, "exit")) {
                        System.out.println("Enter the text you want to send user : -exit");
                        PrivateChat.privateChat(username, username2,Text);
                            Text = scanner.nextLine();
                        }
                }

                    if (Objects.equals(privateChatText, "reply")) {
                        while (!Objects.equals(Text, "exit")) {
                        System.out.println("Enter the number message you want to reply :-exit");
                        Text = scanner.nextLine();
                        String temp = PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                        System.out.println("Enter the text you want to send user : ");
                        Text = scanner.nextLine();
                        PrivateChat.privateChat(username, username2, temp + "....\n" + Text);
                            System.out.println("Enter the number message you want to reply :-exit");
                            Text=scanner.nextLine();
                    }
                }


                    if (Objects.equals(privateChatText, "forward")) {
                        System.out.println("Enter the number message you want to forward :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(Text, "exit")) {
                        String message = PrivateChat.findMessageForward(username, username2, Text);
                        System.out.println("Enter the username with you want to send forward message : ");
                        username2 = scanner.nextLine();
                        forwardChat(username, username2, message);
                            System.out.println("Enter the number message you want to forward :-exit");
                            Text = scanner.nextLine();
                    }
                }


                    if (Objects.equals(privateChatText, "edit")) {
                        System.out.println("Enter the number message you want to edit :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(privateChatText, "exit")) {

                        String oldchat = PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                        System.out.println("Enter the text you want replace message : ");
                        String newchat = scanner.nextLine();
                        PrivateChat.editMessage(username, username2, oldchat, newchat);
                            System.out.println("Enter the number message you want to edit :-exit");
                            Text = scanner.nextLine();
                    }
                }

                    if (Objects.equals(privateChatText, "delete")) {
                        System.out.println("Enter the number message you want to delete :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(privateChatText, "exit")) {
                        String oldchat = PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                        PrivateChat.deleteMessage(username, username2, oldchat);
                            System.out.println("Enter the number message you want to delete :-exit");
                            Text = scanner.nextLine();
                    }
                }
                System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
                privateChatText = scanner.nextLine();
            }
        }
    }

    public static void forwardChat(String username,String username2,String forward) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);
        Scanner scanner = new Scanner(System.in);

        if (tableExist(conn, "blockedUser_" + username2)){
            if (Block.checkBlock(username2,username));{
                System.out.println("you blocked cant send message");
                return;
            }
        }
        while (!tableExist(conn,username2)){
            System.out.println(" username dosent exist enter other username-exit");
            username2 = scanner.nextLine();
            if (Objects.equals(username2, "exit"))
                return;
        }

        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        nameChat=nameChat.toLowerCase(Locale.ROOT);

        String privateChatText = "";
        if(!tableExist(conn,nameChat)){
            System.out.println("Enter the text you want to send user :");
            privateChatText = scanner.nextLine();
            // start chat
            PrivateChat.startPrivateChat(username, username2, privateChatText);
            //continue chat

            System.out.println("if you want finish chat write exit");
            System.out.println("Enter the text you want to send user :");
            PrivateChat.ShowChat(username,username2);
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {
                PrivateChat.privateChat( username, username2, privateChatText);
                privateChatText = scanner.nextLine();
            }
        }
        else {
            System.out.println("Enter one of send message-reply-forward-exit");

            PrivateChat.ShowChat(username,username2);
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {
                if (Objects.equals(privateChatText, "send message")){
                    System.out.println("Enter the text you want to send user : ");
                    privateChatText = scanner.nextLine();
                    PrivateChat.privateChat(username, username2, privateChatText);
                }

                if (Objects.equals(privateChatText, "reply")){
                    System.out.println("Enter the number message you want to reply :");
                    privateChatText = scanner.nextLine();
                    String temp=PrivateChat.findMessage(username,username2, Integer.parseInt(privateChatText));
                    System.out.println("Enter the text you want to send user : ");
                    privateChatText = scanner.nextLine();
                    PrivateChat.privateChat(username, username2, temp+"....\n"+privateChatText);
                }

                if (Objects.equals(privateChatText, "forward")){
                    System.out.println("Enter the number message you want to forward :");
                    privateChatText = scanner.nextLine();
                    String message=PrivateChat.findMessageForward(username,username2,privateChatText);
                    System.out.println("Enter the username with you want to send forward message : ");
                    username2 = scanner.nextLine();
                    forwardChat(username,username2,message);
                }
            }
        }
    }

    public static void createGroup(String owner) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the name group you created:");
        String nameGroup = scanner.nextLine();
        while (tableExist(conn,"group_"+nameGroup)){
            System.out.println("name exist Please Enter another name ");
            nameGroup = scanner.nextLine();
        }
        System.out.println("Enter the id group group you created:");
        String idGroup = scanner.nextLine();
        ArrayList<String> addUsers = new ArrayList<String>();
        ArrayList<String> admins = new ArrayList<String>();
        CreateGroup.createGroup(owner, nameGroup, addUsers, admins,idGroup);
        CreateGroup.addUser(nameGroup, owner);
        String user = "";
        String admin = "";
        System.out.println("Enter the username of the people you want to add to the group: ");
        System.out.println("Enter the exit for go next step");
        user = scanner.nextLine();
        while (!Objects.equals(user, "exit")) {
            CreateGroup.addUser(nameGroup, user);
            CreateGroup.addGroupUser(user,nameGroup,idGroup);
            user = scanner.nextLine();
        }
        System.out.println("Enter the username of the people you want to add to the admins group: ");
        System.out.println("Enter the exit for go next step");
        admin = scanner.nextLine();
        while (!Objects.equals(admin, "exit")) {

            if (CreateGroup.adminIsMember(admin,nameGroup))
            CreateGroup.addAdmin(owner, nameGroup, admin);
            else
                System.out.println("this user is not in group");
            admin = scanner.nextLine();
        }
    }

    public static void mygroup(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        CreateGroup.showMyGroup(username);
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter name group you want access to it or exit ");
        String nameGroup = scanner.nextLine();
        if(nameGroup.startsWith("exit"))
            return;
      if (!CreateGroup.checkUser(nameGroup,username)){
          System.out.println("you don't member this group");
          return;
      }


        String input ="";
        while (input != "exit") {
            System.out.println("Enter one of: add user-show admins-show users-delete user-ban user\n" +
                    "change name group-chat group-show chats in group-exit");
             input=scanner.nextLine();
            if (input.startsWith("exit"))
                return;

            if (input.startsWith("add user")) {
                System.out.println("enter username with you want add");
                String username2 = scanner.nextLine();
                CreateGroup.addUser(nameGroup,username2);
            }

            if (input.startsWith("show admins")) {
                CreateGroup.showAdmins(nameGroup);
            }

            if (input.startsWith("show users")) {
                CreateGroup.showUsers(nameGroup);
            }

            if (input.startsWith("delete user")) {
                System.out.println("enter username with you want delete");
                String username2 = scanner.nextLine();
                if ( CreateGroup.checkAdmin(nameGroup,username)) {
                    CreateGroup.deleteUser(nameGroup,username2);
                }
                else System.out.println("you cant delete user");
            }

            if (input.startsWith("ban user")) {
                System.out.println("enter username with you want ban");
                String username2 = scanner.nextLine();
                if ( CreateGroup.checkAdmin(nameGroup,username)) {
                    CreateGroup.banUser(nameGroup,username2);
                }
                else System.out.println("you cant ban user");
            }

            if (input.startsWith("change name group")) {
                System.out.println("enter the new name : ");
                String newNameGroup = scanner.nextLine();
                if ( CreateGroup.checkAdmin(nameGroup,username)) {
                    CreateGroup.changeNameGroup(nameGroup,newNameGroup);
                }
                else System.out.println("you cant change name group");
            }

            if (input.startsWith("chat group")) {
               if (!CreateGroup.checkBanUser(nameGroup,username)){
                  chatGroup(nameGroup,username);
                }
                else System.out.println("you cant chat in group");
            }

            if (input.startsWith("show chats in group")) {
                CreateGroup.showChats(nameGroup);
            }
            System.out.println("Enter one of: add user-show admins-show users-delete user-ban user-" +
                    "change name group-chat group-show chats in group-exit");
            input=scanner.nextLine();
        }
    }

    public static void chatGroup(String nameGroup,String username) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);
        Scanner scanner = new Scanner(System.in);
        CreateGroup.showChats(nameGroup);
        System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
        String input = scanner.nextLine();
        while (!Objects.equals(input, "exit")) {

            String Text="";
            if (Objects.equals(input, "send message")) {
                System.out.println("Enter the text you want to send user : -exit");
                Text=scanner.nextLine();
                while (!Objects.equals(Text, "exit")) {
                    System.out.println("Enter the text you want to send user : -exit");
                    CreateGroup.chatGroup(nameGroup,username,Text);
                    Text = scanner.nextLine();
                }
            }

            if (Objects.equals(input, "reply")) {
                System.out.println("Enter the number message you want to reply :-exit");
                Text=scanner.nextLine();
                while (!Objects.equals(Text, "exit")) {
                    System.out.println("Enter the number message you want to reply :-exit");
                    Text = scanner.nextLine();
                    String temp = CreateGroup.findMessageGroup(nameGroup,username, Integer.parseInt(Text));
                    System.out.println("Enter the text you want to send user : ");
                    Text = scanner.nextLine();
                    CreateGroup.chatGroup(nameGroup, username, temp + "....\n" + Text);
                    System.out.println("Enter the number message you want to reply :-exit");
                    Text=scanner.nextLine();
                }
            }


            if (Objects.equals(input, "forward")) {
                System.out.println("Enter the number message you want to forward :-exit");
                Text = scanner.nextLine();
                while (!Objects.equals(Text, "exit")) {
                    String message = CreateGroup.findMessageGroup(nameGroup,username, Integer.parseInt(Text));
                    System.out.println("Enter the username with you want to send forward message : ");
                   String username2 = scanner.nextLine();
                    forwardChat(username, username2, message);
                    System.out.println("Enter the number message you want to forward :-exit");
                    Text = scanner.nextLine();
                }
            }


            if (Objects.equals(input, "edit")) {
                System.out.println("Enter the number message you want to edit :-exit");
                Text = scanner.nextLine();
                while (!Objects.equals(Text, "exit")) {

                    String oldchat =CreateGroup.findMessageGroup(nameGroup,username, Integer.parseInt(Text));
                    System.out.println("Enter the text you want replace message : ");
                    String newchat = scanner.nextLine();
                    CreateGroup.editMessageGroup(nameGroup,username, oldchat, newchat);
                    System.out.println("Enter the number message you want to edit :-exit");
                    Text = scanner.nextLine();
                }
            }

            if (Objects.equals(input, "delete")) {
                System.out.println("Enter the number message you want to delete :-exit");
                Text = scanner.nextLine();
                while (!Objects.equals(Text, "exit")) {
                    String oldchat =CreateGroup.findMessageGroup(nameGroup,username, Integer.parseInt(Text));
                   CreateGroup.deleteMessageGroup(nameGroup,username,Text);
                    System.out.println("Enter the number message you want to delete :-exit");
                    Text = scanner.nextLine();
                }
            }
            System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
            input = scanner.nextLine();
        }
        }

    public static void blockUser(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter exit for next step");
        System.out.println("BLOCK user: enter username of the people with you want block ");
        String username2 = scanner.nextLine();
        while (!Objects.equals(username2, "exit")){
            if (!Block.checkBlock(username,username2)){
                //
                Block.addUserBlocked(username, username2);
                Block.addUserBlocked(username2,username);
            }
            else System.out.println("you already blocked user");
           username2 = scanner.nextLine();
        }
    }

    public static void unblock(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection  conn = DriverManager.getConnection(url);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter exit for next step");
        System.out.println("UNBLOCK user: enter username of the people with you want unblock ");
        String username2 = scanner.nextLine();
            while (!Objects.equals(username2, "exit")) {
                if (Block.checkBlock(username,username2)){
                    System.out.println("you unblock user");
                    Block.unblocked(username, username2);
                    Block.unblocked(username2, username);
                }
                else System.out.println("user wasnt block");
                username2 = scanner.nextLine();
            }
        }

    public static boolean tableExist(Connection conn, String tableName) throws SQLException {
      tableName=tableName.toLowerCase(Locale.ROOT);
        boolean tExists = false;
        try (ResultSet rs = conn.getMetaData().getTables(null, null, tableName, null)) {
            while (rs.next()) {
                String tName = rs.getString("TABLE_NAME");
                if (tName != null && tName.equals(tableName)) {
                    tExists = true;
                    break;
                }
            }
        }
        return tExists;
    }

}

