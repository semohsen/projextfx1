package modle;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BusinessAccount {
    private String name;



    public String getName() {
        return name;
    }



    public BusinessAccount(String name) {
        this.name=name;
    }


    public static void processCreateBusinessAccounts(String username) {
      String  BusinessAccount="Business";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "INSERT INTO account Values ('%s', '%s')";
            query = String.format(query , username , BusinessAccount);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("Created Business Accounts");
    }

}
