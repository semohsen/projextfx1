package modle;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ForgetPassword extends UserInfo {

    public static void resetPassword(String username) throws IOException {
        File file = new File("ForgetPassword.txt");
        String data [] = UserInfo.dataForget();
        boolean findIt= false ;
        String password ="";
        for(int i=0 ; i< data.length ; i++)
        {
            if(data[i].startsWith(username))
            {
                findIt = true ;
                System.out.println("What is the name of the town where you were born?");
                Scanner input = new Scanner(System.in);
                String city = input.nextLine();
                System.out.println("Who was your childhood hero?");
                String hero = input.nextLine();
                String temp = username+"-"+city+"-"+hero;
                temp = temp.trim();
                if(data[i].equals(temp))
                {
                    System.out.println("Lets make a new Password ...\n");
                  password=makepassword();
                  String replace = username+"-"+password;
                  replace=replace.trim();
                  UserInfo.replaceUser(replace , username);
                    System.out.println("Your Password is changed ...");

                }
                else
                {
                    System.out.println("Your answer are Incorrect...");
                }
                break;
            }
        }
        if(!findIt)
            System.out.println("User does not found ...");
    }
    public static void makeIt(String make) throws IOException {
        UserInfo.writeToForgetPassword(make);
    }
}
