package modle;

import java.sql.*;
import java.util.ArrayList;

public class Recommend {
    public static ArrayList<String> all_user = new ArrayList<>();
    public static ArrayList<String> notFollow = new ArrayList<>();
    public static ArrayList<String> Following = new ArrayList<>();
    public static void Recommend_user (String username )
    {
        FindNotFollow(username);
        System.out.println("------------------------------------");
        int notFollowNumber = notFollow.size();
        if(notFollowNumber>=3)
            notFollowNumber=3;
        if(notFollowNumber>0) {
            for (int i = 0; i < notFollowNumber; i++) {
                System.out.println((i+1) +" - " + notFollow.get(i));
            }
        }
        else
            System.out.println("you followed everybody :)");
        System.out.println("------------------------------------");
    }
    public static void Recommend_tweet (String username )
    {
        FindNotFollow(username);
        System.out.println("------------------------------------");
        int notFollowNumber = notFollow.size();
        if(notFollowNumber>=3)
            notFollowNumber=3;
        if(notFollowNumber>0) {
            boolean print = false ;
            for (int j = 0; j < notFollowNumber; j++) {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
                    String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
                    Connection connect = DriverManager.getConnection(url);
                    Statement state = connect.createStatement();
                    String query = "SELECT * FROM %s ORDER BY tweets DESC LIMIT 1";
                    String tweet_name = notFollow.get(j)+"_tweet";
                    query = String.format(query , tweet_name);
                    ResultSet rs = state.executeQuery(query);
                    ResultSetMetaData rsmd = rs.getMetaData();
                    int columnsNumber = rsmd.getColumnCount();
                    // Iterate through the data in the result set and display it.
                    while (rs.next()) {
                        //Print one row
                        for(int i = 1 ; i <= 1; i++){
                            if(rs.getString(i)!=null) {
                                System.out.println((j+1)+" -"+notFollow.get(j)+" : "+rs.getString(i));
                                print = true ;
                            }
                        }
                    }
                }
                catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }

            }

            if(!print)
                System.out.println("No tweet found ");

        }
        else
            System.out.println("you followed everybody :)");
        System.out.println("------------------------------------");
    }
    public static void Find_following(String username)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select following from %s ";
            query = String.format(query , username);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        Following.add(rs.getString(i));
                    }
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void FindNotFollow (String username)
    {
        GetAllUser();
        Find_following(username);
        int number = all_user.size();
        for(int i=0 ; i<number ; i++)
        {
            String temp = all_user.get(i);
            if(!Following.contains(temp))
            {
                if(!notFollow.contains(temp))
                notFollow.add(temp);
            }
        }
    }
    public static void GetAllUser ()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=138113351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select user from all_user ";
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        all_user.add(rs.getString(i));
                    }
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
