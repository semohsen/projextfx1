package modle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Follow extends UserInfo {

    public static void follow (String follower , String following )
    {
        //if followingState is true it means that it is a public account and if it is false it means it is a private account
        //private account pending must make
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
                    String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
                    Connection connect = DriverManager.getConnection(url);
                    Statement state = connect.createStatement();
                    String query = "INSERT INTO %s (following) VALUES ('%s')";
                    query = String.format(query, follower, following);
                    state.execute(query);
                    query = "INSERT INTO %s (followers) VALUES ('%s')";
                    query = String.format(query, following, follower);
                    state.execute(query);
                    state.close();
                    connect.close();
                    System.out.format("you followed %s \n" , following);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
    }
    public static void unfollow (String follower , String following )
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "DELETE FROM %s WHERE following='%s'";
            query = String.format(query, follower, following);
            state.execute(query);
            query = "DELETE FROM %s WHERE followers='%s'";
            query = String.format(query, following, follower);
            state.execute(query);
            System.out.format("you unfollow %s\n" , following);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
