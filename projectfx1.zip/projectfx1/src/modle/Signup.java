package modle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Signup extends UserInfo {
    public static void makeUser (String username , String password ) throws IOException {

            String model = username +"-"+password;
            UserInfo.writeToUser(model);
            Scanner input = new Scanner(System.in);
            System.out.println("What is the name of the town where you were born?");
            String city = input.nextLine();
            System.out.println("Who was your childhood hero?");
            String hero = input.nextLine();
            String forget = username+"-"+city+"-"+hero;
            ForgetPassword.makeIt(forget);
            System.out.println("\nUser is made you can login now ...");

    }
    public static boolean findUser(String username) throws IOException {
            boolean userbool = false ;
                    userbool = true ;
                    File user = new File("User.txt");
                    // list that holds strings of a file
                    List<String> listOfStrings = new ArrayList<String>();
                    // load data from file
                    BufferedReader bf = new BufferedReader(new FileReader("User.txt"));
                    // read entire line as string
                    String line = bf.readLine();
                    // checking for end of file
                    while (line != null) {
                            listOfStrings.add(line);
                            line = bf.readLine();
                    }
                    bf.close();
                    String[] data = listOfStrings.toArray(new String[0]);
                    for(int i=0 ; i<data.length ; i++) {
                        if (data[i].startsWith(username)) {
                            userbool = false;
                            System.out.println("Username exist Please Enter another username ... ");
                                break;
                        }
                    }
            return userbool;
    }
}

